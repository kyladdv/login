const express = require("express");
const app = express();
const bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: false }));

app.get('/', (req, res) => {
    res.sendFile(__group-assignment + '/views/index.ejs');
});

app.get('/login', (req, res) => {
    res.sendFile(__group-assignment + '/views/login.ejs');
});

  app.post('/login', (req, res) => {
    let username = req.body.username;
    let password = req.body.password;
    res.send(`Username: ${username} Password: ${password}`);
  });

  app.post

  const port = 5000

app.listen(port, () => console.log(`This app is listening on port ${port}`));

